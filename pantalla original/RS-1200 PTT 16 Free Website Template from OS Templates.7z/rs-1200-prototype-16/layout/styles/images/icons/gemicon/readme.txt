------------------
Gemicon Icon Set (600+ free icons)
A handcrafted icon set by Turqois (http://turqois.com), which there 3 different sizes (16, 32, 64). Each icon created with pixel-perfect shape layer on Photoshop. Released for Smashing Magazine and design community (http://gemicon.net).
------------------


Dear Friends,

Thank you for downloading this file.

This freebie has been brought to you by SmashingMagazine.com. You can freely use it for both your private and commercial projects, including software, online services, templates and themes. You are free to use and edit these icons for any personal or commercial work without credit, however the link back (http://gemicon.net) or credit would be very appreciated. You may not redistribute or sell these icon set on any other website or source.
                     
The designers would love to know if you use this icon set, so please don't hesitate to contact them at 
dturqois@gmail.com, or online (http://turqois.com), on Twitter (http://www.twitter.com/dturqois) and on Dribbble (http://www.dribbble.com/dturqois).

Please also link to the article in which this freebie was released if you would like to spread the word.

Post URL: http://www.smashingmagazine.com/2013/01/06/freebie-gemicon-icon-set-600-psd-source-png/

Zip File: http://provide.smashingmagazine.com/Freebies/free-icon-set-gemicon.zip

Smashing Magazine Team,
www.smashingmagazine.com
